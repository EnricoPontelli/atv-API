USE application;
# admin & admin
INSERT INTO usuarios(nome_de_usuario, senha) VALUES
    ('admin', '$2a$12$nFBW8.bWFFRDrRI04L6vz.DJpmxth2sdV8THDljA0HnnEFkTFwWIi');